import {defineConfig} from 'vite-plus';

export default defineConfig({
  pack: {
    entry: ['src/index.ts', 'src/server/index.ts'],
    format: ['cjs', 'esm'],
    deps: {
      skipNodeModulesBundle: true,
    },
  },
});
